from __future__ import annotations

import copy
import hashlib
import inspect
import json
import os
import socket
import time
import uuid
from collections.abc import Mapping
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from pathlib import Path
from typing import Any, Callable

from baldr_router.agent_gateway import external_agent_catalog_status, get_agent_gateway
from baldr_router.config import AppConfig, RoleConfig
from baldr_router.phase_deliverables import materialize_phase_deliverable
from baldr_router.process_control import terminate_processes_for_run
from baldr_router.provider_registry import (
    provider_isolation_status,
    provider_runtime_identity,
    run_provider_role,
)
from baldr_router.provider_activity import (
    emit_provider_activity,
    generic_activity_for_role,
)
from baldr_router.redaction import redact_text
from baldr_router.runtime_guard import child_provider_env, new_run_id
from baldr_router.telemetry import append_run, utc_now_iso

from .evidence import create_workflow_evidence
from .engine_prompts import (
    _context7_note,
    _structured_instruction as _structured_instruction,
    _workspace_baseline_note,
    architect_prompt,
    fix_prompt,
    implementer_prompt,
    reviewer_prompt,
)
from .engine_snapshot import (
    _resolved_snapshot as _build_resolved_snapshot,
    _role_from_plan,
    _session_key,
)
from .git_workspace import GitWorkspaceError, GitWorkspaceManager, WorkspaceExecution
from .heartbeat import LeaseHeartbeat, WorkflowCancelled
from .identity import identities_match, request_fingerprint, workspace_identity
from .recovery import recover_stale_runs
from .reducers import reduce_phase
from .store import (
    DurableStore,
    IdempotencyConflict,
    LeaseFenceError,
    LeaseToken,
)

ProviderRunner = Callable[..., dict[str, Any]]
FaultHook = Callable[[str, dict[str, Any]], None]

TERMINAL_RUN_STATES = {"approved", "needs_changes", "blocked", "failed", "cancelled"}
RECONCILIATION_ACTIONS = {
    "authorize_changes",
    "decline_changes",
    "resume_from_checkpoint",
    "accept_existing_changes",
    "discard_worktree",
    "inspect_shadow",
    "continue_from_shadow",
    "apply_shadow_changes",
    "discard_shadow",
    "mark_failed",
}


class SimulatedProcessCrash(BaseException):
    """Test-only process-loss signal that deliberately leaves leases stale."""


def _stable_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _workflow_lease_seconds(config_snapshot: dict[str, Any]) -> int:
    """Return the workflow lease duration with its operational floor applied.

    A shorter lease can expire between local Git/SQLite steps before the first
    provider heartbeat has a chance to renew it, so recovery, cancellation and
    execution all share this floor.
    """
    return max(15, int(config_snapshot["durability"].get("lease_seconds") or 45))


def _idempotency_conflict_result(exc: IdempotencyConflict) -> dict[str, Any]:
    return {
        "ok": False,
        "status": "idempotency_conflict",
        "error": {
            "code": "idempotency_conflict",
            "key": exc.key,
            "expected_fingerprint": exc.expected,
            "received_fingerprint": exc.received,
        },
        "reason": str(exc),
    }


def _owner_id() -> str:
    return f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:8]}"


def _safe_text(value: Any, limit: int = 6000) -> str:
    if value is None:
        return ""
    text = (
        value
        if isinstance(value, str)
        else json.dumps(value, ensure_ascii=False, indent=2)
    )
    return text if len(text) <= limit else text[:limit] + "…"


def _extract_summary(result: dict[str, Any]) -> str:
    report = result.get("final_report")
    if isinstance(report, dict):
        return _safe_text(report, 5000)
    for key in ("final_text", "stdout", "stdout_tail", "stderr"):
        if result.get(key):
            return _safe_text(result[key], 5000)
    return _safe_text(result, 5000)


def _reported_file_changes(result: Mapping[str, Any]) -> list[dict[str, str]]:
    """Return the provider's bounded path claims for workspace verification."""

    report = result.get("final_report")
    if not isinstance(report, Mapping):
        return []
    fields = (
        ("files_added", "added"),
        ("files_modified", "modified"),
        ("files_deleted", "deleted"),
    )
    changes: list[dict[str, str]] = []
    seen: set[str] = set()
    for field, kind in fields:
        values = report.get(field)
        if not isinstance(values, list):
            continue
        for value in values:
            if not isinstance(value, str) or not value.strip() or value in seen:
                continue
            seen.add(value)
            changes.append({"path": value, "kind": kind})
            if len(changes) >= 100:
                return changes
    return changes


def _write_authorization_request(result: dict[str, Any]) -> str | None:
    report = result.get("final_report")
    if not isinstance(report, dict):
        return "Crear o modificar archivos para completar el pedido."
    decisions = report.get("decisions")
    if not isinstance(decisions, dict):
        return "Crear o modificar archivos para completar el pedido."
    authorization = str(decisions.get("write_authorization") or "").strip().lower()
    if authorization == "not_required":
        return None
    request = str(decisions.get("write_request") or "").strip()
    return request or "Crear o modificar archivos para completar el pedido."


def _legacy_write_policy_request(result: dict[str, Any]) -> str | None:
    """Recognize pre-contract agents that reported the planning boundary as a blocker."""

    text = json.dumps(result, ensure_ascii=False).lower()
    if any(
        marker in text
        for marker in (
            "regla de no modificar archivos",
            "bloqueada por la regla de no modificar",
            "read-only planning boundary",
            "rule not to modify files",
        )
    ):
        return "Crear o modificar archivos para completar el pedido."
    return None


def _requires_write_authorization(config_snapshot: dict[str, Any]) -> bool:
    workspace = config_snapshot.get("workspace") or {}
    requested_value = workspace.get("requested_safety_mode")
    if requested_value is None:
        # Runs created before this mode must keep their original isolated or
        # direct semantics when their immutable snapshot is resumed.
        return False
    requested = str(requested_value).strip().lower()
    return requested in {"", "auto", "automatic"}


def _has_persisted_direct_write_consent(config_snapshot: dict[str, Any]) -> bool:
    workspace = config_snapshot.get("workspace") or {}
    requested = str(workspace.get("requested_safety_mode") or "").strip().lower()
    return requested in {"current", "non-git"}


def _is_workspace_write_authorization_text(value: Any) -> bool:
    """Recognize a provider's obsolete request to authorize workspace writes."""

    text = str(value or "").strip().lower()
    if not text:
        return False
    authorization_markers = (
        "authoriz",
        "autoriz",
        "permission",
        "permiso",
        "consent",
        "approval",
        "aprobación",
        "aprobacion",
    )
    workspace_markers = (
        "workspace",
        "worktree",
        "repository",
        "repositorio",
        "file",
        "archivo",
        "code",
        "código",
        "codigo",
        "document",
        "documento",
        "report",
        "informe",
        ".md",
        ".py",
        ".ts",
        ".js",
        ".toml",
        ".json",
    )
    change_markers = (
        "write",
        "writ",
        "edit",
        "chang",
        "creat",
        "updat",
        "modif",
        "escri",
        "cambi",
        "crea",
        "actualiz",
    )
    return (
        any(marker in text for marker in authorization_markers)
        and any(marker in text for marker in workspace_markers)
        and any(marker in text for marker in change_markers)
    )


def _normalize_architect_write_authorization(
    result: dict[str, Any], *, authorization_required: bool
) -> dict[str, Any]:
    """Make the durable workspace policy authoritative over model narration.

    In direct mode the workspace already has persisted consent. An architect
    may still repeat an older prompt convention and ask for permission in its
    report; keeping that text would make the UI present a decision that the
    workflow neither needs nor honors.
    """

    if authorization_required:
        return result
    report = result.get("final_report")
    if not isinstance(report, dict):
        return result

    normalized = copy.deepcopy(result)
    normalized_report = normalized["final_report"]
    decisions = normalized_report.get("decisions")
    authorization_narrative_removed = False
    if isinstance(decisions, dict):
        authorization_narrative_removed = bool(
            str(decisions.get("write_authorization") or "").strip().lower()
            == "required"
            or decisions.get("write_request")
        )
        decisions["write_authorization"] = "not_required"
        decisions.pop("write_request", None)
    elif isinstance(decisions, list):
        normalized_decisions: dict[str, str] = {}
        for entry in decisions:
            if not isinstance(entry, dict):
                continue
            key = str(entry.get("key") or "").strip()
            value = str(entry.get("value") or "").strip()
            if key in {"write_authorization", "write_request"}:
                authorization_narrative_removed = (
                    authorization_narrative_removed
                    or key == "write_request"
                    or value.lower() == "required"
                )
                continue
            if key and value:
                normalized_decisions[key] = value
        normalized_decisions["write_authorization"] = "not_required"
        normalized_report["decisions"] = normalized_decisions
    else:
        normalized_report["decisions"] = {"write_authorization": "not_required"}

    narrative_fields = (
        "scope",
        "approach",
        "plan_steps",
        "work_completed",
        "work_next",
        "findings",
        "corrections",
        "verification_evidence",
        "verification_needed",
        "risks",
        "follow_up",
        "constraints",
        "assumptions",
        "alternatives_rejected",
        "acceptance_criteria",
        "blockers",
    )
    for field in narrative_fields:
        values = normalized_report.get(field)
        if not isinstance(values, list):
            continue
        retained = [
            value
            for value in values
            if not _is_workspace_write_authorization_text(value)
        ]
        authorization_narrative_removed = authorization_narrative_removed or len(
            retained
        ) != len(values)
        normalized_report[field] = retained

    for field in ("summary", "interpretation"):
        value = normalized_report.get(field)
        if not _is_workspace_write_authorization_text(value):
            continue
        authorization_narrative_removed = True
        text = str(value).lower()
        normalized_report[field] = (
            "La planificación está completa y la implementación puede continuar."
            if any(marker in text for marker in ("autoriz", "permiso", "informe"))
            else "Planning is complete and implementation can proceed."
        )

    status = str(normalized_report.get("status") or "").strip().lower()
    if (
        authorization_narrative_removed
        and status in {"blocked", "needs_changes", "partial"}
        and not normalized_report.get("blockers")
    ):
        normalized_report["status"] = "planned"
        normalized["status"] = "planned"
        normalized["ok"] = True
        normalized.pop("error_code", None)
        normalized.pop("reason", None)
    return normalized


def _has_blockers(result: dict[str, Any]) -> bool:
    report = result.get("final_report")
    if isinstance(report, dict):
        status = str(report.get("status", "")).lower()
        if status in {"blocked", "needs_changes", "partial"}:
            return True
        text = "\n".join(
            str(item)
            for item in list(report.get("risks") or [])
            + list(report.get("verification_needed") or [])
        ).lower()
        return any(
            word in text
            for word in ("blocker:", "[blocker]", "blocking:", "must fix:", "critical:")
        )
    if isinstance(result.get("participants"), list):
        return any(_has_blockers(item) for item in result["participants"])
    return not bool(result.get("ok"))


def _runner_accepts_activity_sink(runner: ProviderRunner) -> bool:
    """Preserve compatibility with injected provider runners from older clients."""

    try:
        parameters = inspect.signature(runner).parameters.values()
    except (TypeError, ValueError):
        return False
    return any(
        parameter.name == "activity_sink"
        or parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in parameters
    )


def _resolved_snapshot(
    cfg: AppConfig,
    *,
    architect_provider: str | None,
    implementer_provider: str | None,
    reviewer_provider: str | None,
    max_rounds: int | None,
    role_profile_overrides: dict[str, list[str]] | None = None,
    workspace_mode: str | None = None,
    context7_policy: str | None = None,
    execution_preset: str | None = None,
    team_mode: str | None = None,
    agent_overrides: Mapping[str, str] | None = None,
    workspace_root: Path | None = None,
) -> dict[str, Any]:
    """Preserve the engine's injection seam over the extracted snapshot builder."""

    return _build_resolved_snapshot(
        cfg,
        architect_provider=architect_provider,
        implementer_provider=implementer_provider,
        reviewer_provider=reviewer_provider,
        max_rounds=max_rounds,
        role_profile_overrides=role_profile_overrides,
        workspace_mode=workspace_mode,
        context7_policy=context7_policy,
        execution_preset=execution_preset,
        team_mode=team_mode,
        agent_overrides=agent_overrides,
        workspace_root=workspace_root,
        catalog_loader=external_agent_catalog_status,
        gateway_factory=get_agent_gateway,
    )


class DurableWorkflowEngine:
    def __init__(
        self,
        *,
        store: DurableStore | None = None,
        provider_runner: ProviderRunner = run_provider_role,
        fault_hook: FaultHook | None = None,
    ) -> None:
        self.store = store or DurableStore()
        self.provider_runner = provider_runner
        self.fault_hook = fault_hook
        self.workspace_manager = GitWorkspaceManager(self.store)

    def _fault(self, point: str, context: dict[str, Any]) -> None:
        if self.fault_hook:
            self.fault_hook(point, context)

    def recover(self) -> dict[str, Any]:
        return recover_stale_runs(self.store)

    def dry_run(
        self,
        *,
        workspace_root: Path,
        task: str,
        snapshot: dict[str, Any],
        context7_meta: dict[str, Any],
    ) -> dict[str, Any]:
        identity = workspace_identity(workspace_root)
        return {
            "ok": True,
            "dry_run": True,
            "workflow": "architect-implement-review",
            "workspace_root": str(workspace_root),
            "workspace_identity": identity,
            "workspace_mode": str(
                (snapshot.get("workspace") or {}).get("requested_safety_mode")
                or "current"
            ),
            "role_plans": snapshot["role_plans"],
            "roles": {
                role: {
                    **plan,
                    "provider": plan["profiles"][0]["provider"],
                    "model": plan["profiles"][0].get("model"),
                    "reasoning_effort": plan["profiles"][0].get("reasoning_effort"),
                }
                for role, plan in snapshot["role_plans"].items()
            },
            "max_rounds": snapshot["max_rounds"],
            "context7": context7_meta,
            "durability": {
                "enabled": True,
                "database": str(self.store.path),
                "schema": self.store.schema_status(),
            },
            "planned_steps": [
                "architect.plan",
                "implementer.implement",
                "reviewer.review",
                "implementer.fix_blockers?",
                "reviewer.final_review?",
            ],
        }

    def request_cancel(
        self, run_id: str, *, reason: str = "Cancellation requested by client."
    ) -> dict[str, Any]:
        run = self.store.request_cancellation(run_id, reason=reason)
        cleanup = terminate_processes_for_run(run_id, grace_seconds=0.75)
        if run["status"] == "cancelled":
            result = self._result_from_snapshot(self.store.snapshot_run(run_id))
            result["evidence"] = create_workflow_evidence(self.store, run_id)
            result["process_cleanup"] = cleanup
            return result
        owner = _owner_id()
        lease = self.store.acquire_lease(
            run_id, owner, max(15, self.store.config.lease_seconds)
        )
        if lease is not None:
            try:
                self.store.finalize_cancellation(run_id, lease=lease, reason=reason)
            finally:
                self.store.release_lease(lease)
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        result["process_cleanup"] = cleanup
        return result

    def _cancel_only_request(
        self,
        *,
        resume_run_id: str | None,
        cancel_reason: str,
    ) -> dict[str, Any]:
        """Handle a request whose only intent is cancelling a durable run."""
        if not resume_run_id:
            return {
                "ok": False,
                "status": "invalid_request",
                "error": {"code": "cancel_requires_run_id"},
                "reason": "Cancellation requires resume_run_id.",
            }
        return self.request_cancel(resume_run_id, reason=cancel_reason)

    def _apply_start_policies(self, config_snapshot: dict[str, Any]) -> None:
        """Run the configured recovery and maintenance work before executing.

        Maintenance is best effort on purpose: a failed vacuum must never stop a
        workflow that is otherwise ready to run.
        """
        durability = config_snapshot["durability"]
        if durability.get("recovery_on_start", True):
            self.recover()
        if durability.get("maintenance_on_start", False):
            try:
                self.store.maintenance(full=False)
            except Exception:
                pass

    def _resume_rejection(
        self,
        *,
        resume_run_id: str,
        run: dict[str, Any] | None,
        workspace_root: Path,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        """Validate a resume request against its durable run.

        Returns the durable rejection to send back, or the repository identity
        of the persisted workspace when the resume is allowed. The identity is
        returned rather than recomputed by the caller because probing the
        repository costs a Git call.
        """
        if run is None:
            return (
                {
                    "ok": False,
                    "status": "not_found",
                    "error": {"code": "durable_run_not_found"},
                    "reason": f"Durable run {resume_run_id!r} was not found.",
                },
                None,
            )
        if run["status"] in TERMINAL_RUN_STATES:
            return (
                self._result_from_snapshot(self.store.snapshot_run(resume_run_id)),
                None,
            )
        persisted_root = Path(str(run["workspace_root"])).expanduser().resolve()
        if workspace_root != persisted_root:
            return (
                {
                    "ok": False,
                    "run_id": resume_run_id,
                    "status": "resume_rejected",
                    "error": {"code": "resume_workspace_path_mismatch"},
                    "reason": "A durable run can only resume in its original workspace path.",
                    "expected_workspace_root": str(persisted_root),
                    "received_workspace_root": str(workspace_root),
                },
                None,
            )
        actual_identity = workspace_identity(persisted_root)
        expected_identity = run.get("repository_identity") or {}
        if expected_identity and not identities_match(
            expected_identity, actual_identity
        ):
            return (
                {
                    "ok": False,
                    "run_id": resume_run_id,
                    "status": "resume_rejected",
                    "error": {"code": "resume_repository_identity_mismatch"},
                    "reason": (
                        "The repository at the durable workspace path is not the repository "
                        "that originally created this run."
                    ),
                    "expected_repository_fingerprint": expected_identity.get(
                        "repository_fingerprint"
                    ),
                    "actual_repository_fingerprint": actual_identity.get(
                        "repository_fingerprint"
                    ),
                },
                None,
            )
        return (None, actual_identity)

    def run(
        self,
        *,
        workspace_root: Path,
        task: str,
        extra_context: str,
        config_snapshot: dict[str, Any],
        context7_libraries: list[str] | None,
        client_name: str,
        idempotency_key: str | None = None,
        resume_run_id: str | None = None,
        reconciliation_action: str | None = None,
        cancel: bool = False,
        cancel_reason: str = "Cancellation requested by client.",
        work_item_id: str | None = None,
    ) -> dict[str, Any]:
        if cancel:
            return self._cancel_only_request(
                resume_run_id=resume_run_id, cancel_reason=cancel_reason
            )

        self._apply_start_policies(config_snapshot)

        workspace_root = workspace_root.expanduser().resolve()
        owner = _owner_id()
        requested_identity = workspace_identity(workspace_root)

        try:
            if resume_run_id:
                run = self.store.get_run(resume_run_id)
                rejection, actual_identity = self._resume_rejection(
                    resume_run_id=resume_run_id,
                    run=run,
                    workspace_root=workspace_root,
                )
                if rejection is not None:
                    return rejection
                assert run is not None and actual_identity is not None
                requested_identity = actual_identity
                input_value = (
                    self.store.load_artifact(run.get("task_artifact_id")) or {}
                )
                task = str(input_value.get("task") or task)
                extra_context = str(input_value.get("extra_context") or extra_context)
                context7_libraries = (
                    input_value.get("context7_libraries") or context7_libraries
                )
                config_snapshot = run["config_snapshot"]
                run_id = str(run["id"])
            else:
                workflow_name = "architect-implement-review"
                workflow_version = int(config_snapshot["workflow"].get("version") or 1)
                fingerprint = request_fingerprint(
                    workspace=requested_identity,
                    workflow_name=workflow_name,
                    workflow_version=workflow_version,
                    task=task,
                    extra_context=extra_context,
                    context7_libraries=context7_libraries,
                    config_snapshot=config_snapshot,
                )
                candidate_id = new_run_id("workflow")
                run, created = self.store.create_run_with_input(
                    run_id=candidate_id,
                    idempotency_key=idempotency_key,
                    request_fingerprint=fingerprint,
                    resume_token=f"resume-{uuid.uuid4().hex}",
                    workflow_name=workflow_name,
                    workflow_version=workflow_version,
                    workspace_root=str(workspace_root),
                    workspace_id=str(requested_identity["workspace_id"]),
                    repository_identity=requested_identity,
                    client_name=client_name,
                    input_value={
                        "task": task,
                        "extra_context": extra_context,
                        "context7_libraries": context7_libraries or [],
                    },
                    config_snapshot=config_snapshot,
                    work_item_id=work_item_id,
                )
                run_id = str(run["id"])
                if not created:
                    if run["status"] in TERMINAL_RUN_STATES:
                        return self._result_from_snapshot(
                            self.store.snapshot_run(run_id)
                        )
                    config_snapshot = run["config_snapshot"]
                    workspace_root = Path(str(run["workspace_root"])).resolve()
                    requested_identity = (
                        run.get("repository_identity") or requested_identity
                    )
        except IdempotencyConflict as exc:
            return _idempotency_conflict_result(exc)

        lease = self.store.acquire_lease(
            run_id, owner, _workflow_lease_seconds(config_snapshot)
        )
        if lease is None:
            return {
                "ok": False,
                "run_id": run_id,
                "status": "running",
                "reason": "Another Baldr process owns the durable workflow lease.",
            }

        started = time.time()
        release_lease = True
        try:
            run = self.store.get_run(run_id)
            assert run is not None
            if run.get("cancel_requested_at") or run["status"] == "cancelling":
                self.store.finalize_cancellation(
                    run_id, lease=lease, reason=run.get("cancel_reason")
                )
                return self._result_from_snapshot(self.store.snapshot_run(run_id))

            if run["status"] == "awaiting_reconciliation":
                reconciliation = self._apply_reconciliation(
                    run=run,
                    workspace_root=workspace_root,
                    action=reconciliation_action,
                    lease=lease,
                )
                if not reconciliation.get("continue"):
                    return reconciliation["result"]
                run = self.store.get_run(run_id) or run

            if run["status"] == "pending":
                self.store.transition_run(run_id, "running", lease=lease)
            elif run["status"] in {"interrupted", "unknown"}:
                self.store.transition_run(run_id, "recovering", lease=lease)
                self.store.transition_run(run_id, "running", lease=lease)
            elif run["status"] == "recovering":
                self.store.transition_run(run_id, "running", lease=lease)

            self._fault(
                "workflow.running", {"run_id": run_id, "lease_epoch": lease.epoch}
            )
            context7_note, _context7_meta = _context7_note(
                workspace_root,
                task + "\n" + extra_context,
                context7_libraries,
                context_config=dict(config_snapshot.get("context7") or {}),
            )
            execution = self._restore_or_prepare_workspace(
                run_id=run_id,
                workspace_root=workspace_root,
                config_snapshot=config_snapshot,
                lease=lease,
            )
            if execution.isolated:
                violations: list[dict[str, Any]] = []
                for phase, plan in config_snapshot["role_plans"].items():
                    for profile in plan["profiles"]:
                        status = provider_isolation_status(
                            str(profile["provider"]),
                            can_write=bool(plan["can_write"]),
                            runner=str(profile.get("runner") or ""),
                            sandbox=str(plan.get("sandbox") or ""),
                            agent_ref=str(profile.get("agent_ref") or ""),
                            agent_transport=str(profile.get("agent_transport") or ""),
                        )
                        if not status["ok"]:
                            violations.append(
                                {
                                    "phase": phase,
                                    "profile": str(profile.get("name") or ""),
                                    **status,
                                }
                            )
                if violations:
                    cleanup_error: GitWorkspaceError | None = None
                    try:
                        # No provider has run yet, so this allocation contains
                        # only the verified baseline and is safe to discard.
                        self.workspace_manager.discard_workspace(execution, lease=lease)
                    except GitWorkspaceError as exc:
                        cleanup_error = exc
                    return self._finish_failed(
                        run_id,
                        started,
                        "blocked",
                        "A selected provider cannot be confined to BALDR's protected copy.",
                        {
                            "ok": False,
                            "error": {
                                "code": "provider_isolation_not_enforced",
                                "retryable": False,
                                "violations": violations,
                            },
                            "reason": (
                                "Choose a provider with an enforced workspace boundary, "
                                "or explicitly select a direct/unprotected workspace mode."
                            ),
                        },
                        lease,
                        error_code="provider_isolation_not_enforced",
                        execution=execution if cleanup_error is not None else None,
                    )
            workspace_id = str(requested_identity["workspace_id"])
            workspace_baseline_note = _workspace_baseline_note(execution)

            architecture = self._execute_phase(
                run_id=run_id,
                workspace_id=workspace_id,
                repository_identity=requested_identity,
                step_key="architect.plan",
                phase="architect",
                sequence_number=10,
                round_number=0,
                plan=config_snapshot["role_plans"]["architect"],
                cwd=execution.execution_root,
                prompt=architect_prompt(
                    task,
                    extra_context,
                    context7_note,
                    write_authorization_required=not _has_persisted_direct_write_consent(
                        config_snapshot
                    ),
                ),
                report_kind="plan",
                lease=lease,
                config_snapshot=config_snapshot,
            )
            if not architecture.get("ok"):
                legacy_request = _legacy_write_policy_request(architecture)
                if legacy_request:
                    return self._pause_for_write_authorization(
                        run_id=run_id,
                        request=legacy_request,
                        execution=execution,
                        lease=lease,
                        replay_architect=True,
                    )
                return self._finish_failed(
                    run_id,
                    started,
                    "blocked",
                    "Architecture phase failed.",
                    architecture,
                    lease,
                    error_code=str(
                        architecture.get("error_code") or "workflow_phase_failed"
                    ),
                    execution=execution,
                )
            plan_summary = _extract_summary(architecture)
            write_request = _write_authorization_request(architecture)
            current_run = self.store.get_run(run_id) or {}
            authorization = str(
                (current_run.get("reconciliation") or {}).get("authorization") or ""
            ).lower()
            if (
                write_request
                and authorization != "granted"
                and _requires_write_authorization(config_snapshot)
            ):
                return self._pause_for_write_authorization(
                    run_id=run_id,
                    request=write_request,
                    execution=execution,
                    lease=lease,
                )

            implementation = self._execute_phase(
                run_id=run_id,
                workspace_id=workspace_id,
                repository_identity=requested_identity,
                step_key="implementer.implement",
                phase="implementer",
                sequence_number=20,
                round_number=0,
                plan=config_snapshot["role_plans"]["implementer"],
                cwd=execution.execution_root,
                prompt=implementer_prompt(
                    task,
                    plan_summary,
                    extra_context,
                    context7_note,
                    workspace_baseline_note,
                ),
                report_kind="implementation",
                lease=lease,
                config_snapshot=config_snapshot,
                post_success=lambda step_id, reported: (
                    self.workspace_manager.checkpoint(
                        execution,
                        step_id=step_id,
                        label="implementer.implement",
                        reported_file_changes=reported,
                        lease=lease,
                    )
                ),
            )
            if not implementation.get("ok"):
                return self._finish_failed(
                    run_id,
                    started,
                    "blocked",
                    "Implementation phase failed.",
                    implementation,
                    lease,
                    error_code=str(
                        implementation.get("error_code") or "workflow_phase_failed"
                    ),
                    execution=execution,
                )
            implementation_summary = _extract_summary(implementation)

            review_result: dict[str, Any] | None = None
            rounds = int(config_snapshot.get("max_rounds") or 0)
            for round_index in range(rounds + 1):
                review_key = (
                    "reviewer.review"
                    if round_index == 0
                    else f"reviewer.review_round_{round_index}"
                )
                review_result = self._execute_phase(
                    run_id=run_id,
                    workspace_id=workspace_id,
                    repository_identity=requested_identity,
                    step_key=review_key,
                    phase="reviewer",
                    sequence_number=30 + round_index * 20,
                    round_number=round_index,
                    plan=config_snapshot["role_plans"]["reviewer"],
                    cwd=execution.execution_root,
                    prompt=reviewer_prompt(
                        task,
                        plan_summary,
                        implementation_summary,
                        extra_context,
                        workspace_baseline_note,
                    ),
                    report_kind="review",
                    lease=lease,
                    config_snapshot=config_snapshot,
                )
                if not review_result.get("ok"):
                    return self._finish_failed(
                        run_id,
                        started,
                        "blocked",
                        "Review phase failed.",
                        review_result,
                        lease,
                        error_code=str(
                            review_result.get("error_code") or "workflow_phase_failed"
                        ),
                        execution=execution,
                    )
                if not _has_blockers(review_result):
                    break
                if round_index >= rounds:
                    break
                fix_key = f"implementer.fix_round_{round_index + 1}"
                fix_result = self._execute_phase(
                    run_id=run_id,
                    workspace_id=workspace_id,
                    repository_identity=requested_identity,
                    step_key=fix_key,
                    phase="implementer",
                    sequence_number=40 + round_index * 20,
                    round_number=round_index + 1,
                    plan=config_snapshot["role_plans"]["implementer"],
                    cwd=execution.execution_root,
                    prompt=fix_prompt(
                        task,
                        plan_summary,
                        _extract_summary(review_result),
                        extra_context,
                        workspace_baseline_note,
                    ),
                    report_kind="implementation",
                    lease=lease,
                    config_snapshot=config_snapshot,
                    post_success=lambda step_id, reported: (
                        self.workspace_manager.checkpoint(
                            execution,
                            step_id=step_id,
                            label=fix_key,
                            reported_file_changes=reported,
                            lease=lease,
                        )
                    ),
                )
                if not fix_result.get("ok"):
                    return self._finish_failed(
                        run_id,
                        started,
                        "blocked",
                        "Fix phase failed.",
                        fix_result,
                        lease,
                        error_code=str(
                            fix_result.get("error_code") or "workflow_phase_failed"
                        ),
                        execution=execution,
                    )
                implementation_summary = _extract_summary(fix_result)

            approved = bool(review_result and not _has_blockers(review_result))
            publication: dict[str, Any] | None = None
            if approved:
                # Publication is an externally visible, retryable finalization
                # step. Keeping it non-terminal lets recovery safely re-enter
                # an idempotent publish after a process or machine restart.
                self.store.transition_run(
                    run_id,
                    "finalizing",
                    event_type="workflow.finalization_started",
                    payload={"workspace_mode": execution.mode},
                    lease=lease,
                )
            if approved and config_snapshot["workspace"].get(
                "publish_worktree_changes", True
            ):
                try:
                    publication = self.workspace_manager.publish(execution, lease=lease)
                except GitWorkspaceError as exc:
                    details = self.workspace_manager.reconciliation_status(execution)
                    self.store.transition_run(
                        run_id,
                        "awaiting_reconciliation",
                        event_type="workflow.publication_requires_reconciliation",
                        payload={"reason": str(exc), "error_code": exc.code},
                        error_code=exc.code or "workspace_publication_conflict",
                        error_reason=str(exc),
                        reconciliation={
                            "reason": "workspace-publication-conflict",
                            "message": str(exc),
                            "error_code": exc.code,
                            "review_approved": True,
                            "details": exc.details,
                            **details,
                        },
                        lease=lease,
                    )
                    return self._result_from_snapshot(self.store.snapshot_run(run_id))

            final_report = {
                "status": "approved" if approved else "needs_changes",
                "summary": (
                    "Durable workflow completed with review approval."
                    if approved
                    else "Durable workflow completed but review still reports blockers."
                ),
                "architecture": plan_summary,
                "implementation": implementation_summary,
                "review": _extract_summary(review_result or {}),
                "publication": publication,
            }
            final_artifact = self.store.store_artifact(
                run_id=run_id, kind="workflow-final-report", value=final_report
            )
            target = "approved" if approved else "needs_changes"
            if not approved and execution.mode == "shadow":
                return self._retain_shadow_for_reconciliation(
                    run_id=run_id,
                    report=final_report,
                    execution=execution,
                    error_code="workflow_review_needs_changes",
                    error_reason=(
                        "Review did not approve the protected changes. Inspect, continue, "
                        "apply, or discard the durable copy."
                    ),
                    review_approved=False,
                    lease=lease,
                    final_artifact_id=final_artifact,
                )
            self.store.transition_run(
                run_id,
                target,
                final_artifact_id=final_artifact,
                payload={"duration_ms": int((time.time() - started) * 1000)},
                reconciliation={},
                lease=lease,
            )
            evidence = create_workflow_evidence(self.store, run_id)
            cleanup_requested = bool(
                approved
                and (
                    (
                        execution.mode == "worktree"
                        and config_snapshot["workspace"].get(
                            "cleanup_successful_worktrees", True
                        )
                    )
                    or (
                        execution.mode == "shadow"
                        and config_snapshot["workspace"].get(
                            "cleanup_successful_shadow_workspaces", True
                        )
                        and int(
                            config_snapshot["workspace"].get(
                                "shadow_success_retention_hours", 0
                            )
                            or 0
                        )
                        <= 0
                    )
                )
            )
            if cleanup_requested:
                try:
                    cleanup = self.workspace_manager.cleanup(execution)
                    if execution.checkpoint_id:
                        self.store.mark_checkpoint_status(
                            execution.checkpoint_id,
                            "cleaned",
                            metadata={
                                "cleaned_at": utc_now_iso(),
                                "cleanup": cleanup,
                            },
                            lease=lease,
                        )
                except GitWorkspaceError as exc:
                    # Publication is already verified. Keep durable metadata so
                    # startup maintenance can retry cleanup without changing
                    # the approved result.
                    if execution.checkpoint_id:
                        self.store.mark_checkpoint_status(
                            execution.checkpoint_id,
                            "cleanup_pending",
                            metadata={
                                "cleanup_error_code": exc.code,
                                "cleanup_error": str(exc),
                            },
                            lease=lease,
                        )
            result = self._result_from_snapshot(self.store.snapshot_run(run_id))
            result["evidence"] = evidence
            self._append_telemetry(result)
            return result
        except SimulatedProcessCrash:
            release_lease = False
            raise
        except WorkflowCancelled as exc:
            return self._cancelled_run_result(run_id, lease=lease, exc=exc)
        except LeaseFenceError as exc:
            return self._stale_worker_result(run_id, exc=exc)
        except GitWorkspaceError as exc:
            return self._workspace_reconciliation_result(run_id, lease=lease, exc=exc)
        except Exception as exc:
            return self._engine_failure_result(run_id, lease=lease, exc=exc)
        finally:
            if release_lease:
                self.store.release_lease(lease)

    def _cancelled_run_result(
        self,
        run_id: str,
        *,
        lease: Any,
        exc: WorkflowCancelled,
    ) -> dict[str, Any]:
        """Finalize a cancelled run and attach its evidence bundle."""
        terminate_processes_for_run(run_id, grace_seconds=0.75)
        try:
            self.store.finalize_cancellation(run_id, lease=lease, reason=str(exc))
        except LeaseFenceError:
            pass
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        return result

    def _stale_worker_result(
        self,
        run_id: str,
        *,
        exc: LeaseFenceError,
    ) -> dict[str, Any]:
        """Report that this worker lost the lease and must not persist anything."""
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result.update(
            {
                "ok": False,
                "stale_worker": True,
                "reason": str(exc),
                "error": {"code": "lease_fence_rejected"},
            }
        )
        return result

    def _workspace_reconciliation_result(
        self,
        run_id: str,
        *,
        lease: Any,
        exc: GitWorkspaceError,
    ) -> dict[str, Any]:
        """Park a run whose workspace state can no longer be trusted.

        Recording the reconciliation is best effort: if the durable transition
        fails too, the caller still receives the run snapshot instead of an
        exception that would hide the original workspace error.
        """
        try:
            current_run = self.store.get_run(run_id) or {}
            checkpoint = self.store.latest_checkpoint(run_id)
            execution = (
                self.workspace_manager.from_checkpoint(checkpoint)
                if checkpoint
                else None
            )
            details = (
                self.workspace_manager.reconciliation_status(execution)
                if execution
                else {"allowed_actions": ["mark_failed"]}
            )
            self.store.transition_run(
                run_id,
                "awaiting_reconciliation",
                event_type="workflow.workspace_requires_reconciliation",
                error_code=exc.code or "workspace_reconciliation_required",
                error_reason=str(exc),
                reconciliation={
                    "reason": "workspace-state-invalid",
                    "message": str(exc),
                    "error_code": exc.code,
                    "review_approved": bool(
                        str(current_run.get("status") or "") == "finalizing"
                        or (current_run.get("reconciliation") or {}).get(
                            "review_approved"
                        )
                    ),
                    "details": exc.details,
                    **details,
                },
                lease=lease,
            )
        except Exception:
            pass
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["reason"] = str(exc)
        return result

    def _engine_failure_result(
        self,
        run_id: str,
        *,
        lease: Any,
        exc: BaseException,
    ) -> dict[str, Any]:
        """Fail a run without discarding recoverable shadow work.

        A shadow execution keeps uncertain changes reviewable, so the run is
        parked for reconciliation instead of being marked failed outright.
        """
        run = self.store.get_run(run_id)
        if run and run["status"] not in TERMINAL_RUN_STATES:
            try:
                checkpoint = self.store.latest_checkpoint(run_id)
                execution = (
                    self.workspace_manager.from_checkpoint(checkpoint)
                    if checkpoint
                    else None
                )
                if execution is not None and execution.mode == "shadow":
                    details = self.workspace_manager.reconciliation_status(execution)
                    self.store.transition_run(
                        run_id,
                        "awaiting_reconciliation",
                        event_type="workflow.shadow_retained_after_engine_failure",
                        error_code="durable_engine_failed",
                        error_reason=str(exc),
                        reconciliation={
                            "reason": "durable-engine-failure",
                            "message": str(exc),
                            "error_code": "durable_engine_failed",
                            "review_approved": bool(
                                str(run.get("status") or "") == "finalizing"
                                or (run.get("reconciliation") or {}).get(
                                    "review_approved"
                                )
                            ),
                            **details,
                        },
                        lease=lease,
                    )
                else:
                    self.store.transition_run(
                        run_id,
                        "failed",
                        error_code="durable_engine_failed",
                        error_reason=str(exc),
                        lease=lease,
                    )
            except Exception:
                pass
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["reason"] = str(exc)
        return result

    def _apply_reconciliation(
        self,
        *,
        run: dict[str, Any],
        workspace_root: Path,
        action: str | None,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        run_id = str(run["id"])
        recorded_reconciliation = run.get("reconciliation") or {}
        if recorded_reconciliation.get("reason") == "write-authorization-required":
            return self._resolve_write_authorization(
                run_id=run_id,
                recorded_reconciliation=recorded_reconciliation,
                action=action,
                lease=lease,
            )

        legacy_write_authorization = self._legacy_write_policy_failure(run_id, run)
        authorization_granted = False
        if legacy_write_authorization and action in {
            "authorize_changes",
            "decline_changes",
        }:
            if action == "decline_changes":
                return self._decline_write_authorization(run_id, lease=lease)
            authorization_granted = True
            action = "continue_from_shadow"

        checkpoint = self.store.latest_checkpoint(run_id)
        execution = (
            self.workspace_manager.from_checkpoint(checkpoint) if checkpoint else None
        )
        workspace_config = (run.get("config_snapshot") or {}).get("workspace") or {}
        details = self._reconciliation_details(
            run=run,
            execution=execution,
            workspace_root=workspace_root,
        )
        if not action:
            result = self._result_from_snapshot(self.store.snapshot_run(run_id))
            result.update(
                {
                    "ok": False,
                    "status": "awaiting_reconciliation",
                    "reason": run.get("error_reason"),
                    "reconciliation": {**(run.get("reconciliation") or {}), **details},
                }
            )
            return {"continue": False, "result": result}
        action = action.strip().lower()
        rejection = self._reconciliation_rejection(
            run_id=run_id, action=action, details=details
        )
        if rejection is not None:
            return rejection
        return self._perform_reconciliation(
            run=run,
            run_id=run_id,
            action=action,
            details=details,
            execution=execution,
            workspace_config=workspace_config,
            authorization_granted=authorization_granted,
            lease=lease,
        )

    def _decline_write_authorization(
        self, run_id: str, *, lease: LeaseToken
    ) -> dict[str, Any]:
        """Cancel a run whose workspace changes the person refused."""
        self.store.transition_run(
            run_id,
            "cancelled",
            event_type="workflow.write_authorization_declined",
            error_code="write_authorization_declined",
            error_reason="The person declined workspace changes.",
            reconciliation={
                "reason": "write-authorization-resolved",
                "authorization": "declined",
                "resolved_by": "decline_changes",
                "resolved_at": utc_now_iso(),
            },
            lease=lease,
        )
        return {
            "continue": False,
            "result": self._result_from_snapshot(self.store.snapshot_run(run_id)),
        }

    def _reconciliation_details(
        self,
        *,
        run: dict[str, Any],
        execution: Any,
        workspace_root: Path,
    ) -> dict[str, Any]:
        """Describe which reconciliation actions the recorded state allows.

        A run without a workspace checkpoint can only be marked failed, unless it
        ran in place in a non-Git workspace, where accepting the existing changes
        is also safe.
        """
        if execution:
            return self.workspace_manager.reconciliation_status(execution)
        workspace_config = (run.get("config_snapshot") or {}).get("workspace") or {}
        repository_identity = run.get("repository_identity") or {}
        non_git_run = bool(
            workspace_config.get("allow_non_git") is True
            or repository_identity.get("git") is False
        )
        if not non_git_run:
            return {"allowed_actions": ["mark_failed"]}
        return {
            "allowed_actions": ["accept_existing_changes", "mark_failed"],
            "mode": "in-place",
            "original_exists": workspace_root.exists(),
            "execution_exists": workspace_root.exists(),
            "execution_is_git": False,
            "recoverable": False,
        }

    def _reconciliation_rejection(
        self,
        *,
        run_id: str,
        action: str,
        details: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Refuse an action that is unknown or unsafe for the recorded state."""
        if action not in RECONCILIATION_ACTIONS:
            error_code = "invalid_reconciliation_action"
            reason = f"Unsupported reconciliation action: {action}"
        elif (
            action not in set(details.get("allowed_actions") or [])
            and action != "mark_failed"
        ):
            error_code = "unsafe_reconciliation_action"
            reason = (
                f"Action {action!r} is not safe for the recorded workspace state."
            )
        else:
            return None
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result.update(
            {
                "ok": False,
                "status": "awaiting_reconciliation",
                "error": {"code": error_code},
                "reason": reason,
                "reconciliation": details,
            }
        )
        return {"continue": False, "result": result}

    def _resolve_write_authorization(
        self,
        *,
        run_id: str,
        recorded_reconciliation: dict[str, Any],
        action: str | None,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Resolve a run parked because Baldr needs permission to write.

        This gate is deliberately narrower than general reconciliation: the only
        answers are granting or declining the change, so an unrelated action is
        rejected rather than interpreted.
        """
        allowed_actions = {"authorize_changes", "decline_changes"}
        if not action:
            result = self._result_from_snapshot(self.store.snapshot_run(run_id))
            result.update(
                {
                    "ok": False,
                    "status": "awaiting_reconciliation",
                    "reason": "Baldr necesita autorización para modificar archivos.",
                    "reconciliation": {
                        "reason": "write-authorization-required",
                        "allowed_actions": sorted(allowed_actions),
                    },
                }
            )
            return {"continue": False, "result": result}
        action = action.strip().lower()
        if action not in allowed_actions:
            result = self._result_from_snapshot(self.store.snapshot_run(run_id))
            result.update(
                {
                    "ok": False,
                    "status": "awaiting_reconciliation",
                    "error": {"code": "invalid_write_authorization_action"},
                    "reason": "Elegí si Baldr puede modificar archivos.",
                    "reconciliation": {
                        "reason": "write-authorization-required",
                        "allowed_actions": sorted(allowed_actions),
                    },
                }
            )
            return {"continue": False, "result": result}
        if action == "decline_changes":
            self.store.transition_run(
                run_id,
                "cancelled",
                event_type="workflow.write_authorization_declined",
                error_code="write_authorization_declined",
                error_reason="The person declined workspace changes.",
                reconciliation={
                    "reason": "write-authorization-resolved",
                    "authorization": "declined",
                    "resolved_by": action,
                    "resolved_at": utc_now_iso(),
                },
                lease=lease,
            )
            return {
                "continue": False,
                "result": self._result_from_snapshot(
                    self.store.snapshot_run(run_id)
                ),
            }
        resolved = {
            "reason": "write-authorization-resolved",
            "authorization": "granted",
            "resolved_by": action,
            "resolved_at": utc_now_iso(),
        }
        if recorded_reconciliation.get("replay_architect") is True:
            architect_step = self.store.get_step(run_id, "architect.plan")
            if architect_step and str(architect_step.get("status") or "") in {
                "unknown",
                "interrupted",
                "failed",
            }:
                self.store.reset_step_for_retry(
                    str(architect_step["id"]),
                    reason="operator:authorize_changes:legacy-write-policy",
                    lease=lease,
                    retry_successful_participants=True,
                )
        self.store.transition_run(
            run_id,
            "recovering",
            event_type="workflow.write_authorization_granted",
            reconciliation=resolved,
            lease=lease,
        )
        self.store.transition_run(
            run_id,
            "running",
            reconciliation=resolved,
            lease=lease,
        )
        return {"continue": True}

    def _reconcile_inspect(
        self,
        *,
        run: dict[str, Any],
        run_id: str,
        details: dict[str, Any],
    ) -> dict[str, Any]:
        """Report the parked state without changing it."""
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result.update(
            {
                "ok": False,
                "status": "awaiting_reconciliation",
                "reason": run.get("error_reason"),
                "reconciliation": {
                    **(run.get("reconciliation") or {}),
                    **details,
                    "inspected_at": utc_now_iso(),
                },
            }
        )
        return {"continue": False, "result": result}

    def _reconcile_mark_failed(
        self,
        run_id: str,
        *,
        action: str,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Close an ambiguous write workflow as failed at operator request."""
        self.store.transition_run(
            run_id,
            "failed",
            event_type="workflow.reconciliation_marked_failed",
            error_code="operator_marked_failed",
            error_reason="The operator marked an ambiguous write workflow as failed.",
            reconciliation={"resolved_by": action},
            lease=lease,
        )
        return {
            "continue": False,
            "result": self._result_from_snapshot(self.store.snapshot_run(run_id)),
        }

    def _reconcile_discard_shadow(
        self,
        run_id: str,
        *,
        action: str,
        execution: Any,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Destroy the protected shadow workspace and fail the run."""
        if execution is None or execution.mode != "shadow":
            raise GitWorkspaceError(
                "No shadow workspace exists for this reconciliation.",
                code="shadow_workspace_missing",
            )
        self.workspace_manager.discard_workspace(execution, lease=lease)
        self.store.transition_run(
            run_id,
            "failed",
            event_type="workflow.shadow_discarded",
            error_code="operator_discarded_shadow",
            error_reason="The operator discarded the protected shadow workspace.",
            reconciliation={"resolved_by": action, "resolved_at": utc_now_iso()},
            lease=lease,
        )
        return {
            "continue": False,
            "result": self._result_from_snapshot(self.store.snapshot_run(run_id)),
        }

    def _reconcile_accept_existing(
        self,
        *,
        run_id: str,
        unknown_steps: list[dict[str, Any]],
        execution: Any,
        lease: LeaseToken,
    ) -> None:
        """Accept the workspace as it stands for every uncertain step.

        Without an execution the workspace was changed in place, so the
        checkpoint is recorded as an observation instead of a recoverable one.
        """
        for step in unknown_steps:
            checkpoint_result = (
                self.workspace_manager.checkpoint(
                    execution,
                    step_id=str(step["id"]),
                    label="operator-accepted-existing-changes",
                    lease=lease,
                )
                if execution is not None
                else {
                    "ok": True,
                    "mode": "in-place",
                    "checkpoint_id": None,
                    "recoverable": False,
                    "observation_only": True,
                }
            )
            report = {
                "ok": True,
                "status": "implemented",
                "final_report": {
                    "status": "implemented",
                    "summary": "The operator accepted the existing workspace changes after reconciliation.",
                    "changes_added": [],
                    "changes_modified": [],
                    "changes_removed": [],
                    "files_added": [],
                    "files_modified": [],
                    "files_deleted": [],
                    "commands_run": [],
                    "tests_run": [],
                    "verification_needed": [
                        "Review the reconciled diff before approval."
                    ],
                    "risks": [],
                    "follow_up": [],
                    "decisions": {},
                    "constraints": [],
                    "assumptions": [],
                    "alternatives_rejected": [],
                    "acceptance_criteria": [],
                    "blockers": [],
                    "review_decision": "not_applicable",
                },
                "checkpoint": checkpoint_result,
                "reconciled": True,
            }
            artifact = self.store.store_artifact(
                run_id=run_id, kind="reconciled-write-result", value=report
            )
            self.store.accept_unknown_step(
                str(step["id"]),
                result_artifact_id=artifact,
                reason="operator accepted existing changes",
                lease=lease,
            )

    def _reconcile_apply_shadow(
        self,
        *,
        run: dict[str, Any],
        run_id: str,
        action: str,
        execution: Any,
        workspace_config: dict[str, Any],
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Publish a verified shadow checkpoint on the operator's behalf.

        The run reaches its terminal state here, so the outcome carries the
        publication and its evidence instead of returning to execution.
        """
        if execution is None or execution.mode != "shadow":
            raise GitWorkspaceError(
                "No shadow checkpoint exists to apply.",
                code="shadow_checkpoint_missing",
            )
        publication = self.workspace_manager.publish(execution, lease=lease)
        review_approved = bool((run.get("reconciliation") or {}).get("review_approved"))
        target = "approved" if review_approved else "needs_changes"
        report = {
            "status": target,
            "summary": "The operator safely applied the verified shadow checkpoint.",
            "publication": publication,
            "operator_action": action,
        }
        artifact = self.store.store_artifact(
            run_id=run_id,
            kind="workflow-final-report",
            value=report,
        )
        self.store.transition_run(
            run_id,
            target,
            event_type="workflow.shadow_applied_by_operator",
            final_artifact_id=artifact,
            reconciliation={
                "resolved_by": action,
                "resolved_at": utc_now_iso(),
                "publication_id": publication.get("publication_id"),
            },
            lease=lease,
        )
        self._cleanup_applied_shadow(
            execution=execution, workspace_config=workspace_config, lease=lease
        )
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        result["publication"] = publication
        self._append_telemetry(result)
        return {"continue": False, "result": result}

    def _cleanup_applied_shadow(
        self,
        *,
        execution: Any,
        workspace_config: dict[str, Any],
        lease: LeaseToken,
    ) -> None:
        """Remove a published shadow workspace when retention does not keep it.

        A failed cleanup leaves the checkpoint marked ``cleanup_pending`` rather
        than failing the publication that already succeeded.
        """
        cleanup_requested = bool(
            workspace_config.get("cleanup_successful_shadow_workspaces", True)
            and int(workspace_config.get("shadow_success_retention_hours", 0) or 0) <= 0
        )
        if not cleanup_requested:
            return
        try:
            cleanup = self.workspace_manager.cleanup(execution)
        except GitWorkspaceError as exc:
            if execution.checkpoint_id:
                self.store.mark_checkpoint_status(
                    execution.checkpoint_id,
                    "cleanup_pending",
                    metadata={
                        "cleanup_error_code": exc.code,
                        "cleanup_error": str(exc),
                    },
                    lease=lease,
                )
            return
        if execution.checkpoint_id:
            self.store.mark_checkpoint_status(
                execution.checkpoint_id,
                "cleaned",
                metadata={"cleaned_at": utc_now_iso(), "cleanup": cleanup},
                lease=lease,
            )

    def _perform_reconciliation(
        self,
        *,
        run: dict[str, Any],
        run_id: str,
        action: str,
        details: dict[str, Any],
        execution: Any,
        workspace_config: dict[str, Any],
        authorization_granted: bool,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Apply one validated reconciliation action to a parked run.

        Three actions are terminal reads or decisions and return immediately.
        The rest converge on the shared resolution that puts the run back into
        execution.
        """
        if action == "inspect_shadow":
            return self._reconcile_inspect(run=run, run_id=run_id, details=details)
        if action == "mark_failed":
            return self._reconcile_mark_failed(run_id, action=action, lease=lease)
        if action == "discard_shadow":
            return self._reconcile_discard_shadow(
                run_id, action=action, execution=execution, lease=lease
            )

        snapshot = self.store.snapshot_run(run_id, include_events=False)
        unknown_steps = [
            step for step in snapshot["steps"] if step["status"] == "unknown"
        ]
        legacy_architect_step = (
            self.store.get_step(run_id, "architect.plan")
            if authorization_granted
            else None
        )
        legacy_architect_step_id = str((legacy_architect_step or {}).get("id") or "")

        if action in {
            "resume_from_checkpoint",
            "continue_from_shadow",
            "discard_worktree",
        }:
            if execution is None:
                raise GitWorkspaceError(
                    "No workspace checkpoint exists for reconciliation."
                )
            self.workspace_manager.restore_checkpoint(execution, lease=lease)
            for step in unknown_steps:
                self.store.reset_step_for_retry(
                    str(step["id"]),
                    reason=f"operator:{action}",
                    lease=lease,
                    retry_successful_participants=(
                        authorization_granted
                        and str(step["id"]) == legacy_architect_step_id
                    ),
                )
        elif action == "apply_shadow_changes":
            return self._reconcile_apply_shadow(
                run=run,
                run_id=run_id,
                action=action,
                execution=execution,
                workspace_config=workspace_config,
                lease=lease,
            )
        elif action == "accept_existing_changes":
            self._reconcile_accept_existing(
                run_id=run_id,
                unknown_steps=unknown_steps,
                execution=execution,
                lease=lease,
            )

        if authorization_granted:
            architect_step = self.store.get_step(run_id, "architect.plan")
            if architect_step and str(architect_step.get("status") or "") in {
                "unknown",
                "interrupted",
                "failed",
            }:
                self.store.reset_step_for_retry(
                    str(architect_step["id"]),
                    reason="operator:authorize_changes:legacy-write-policy",
                    lease=lease,
                    retry_successful_participants=True,
                )

        resolved_reconciliation = {
            "resolved_by": "authorize_changes" if authorization_granted else action,
            "resolved_at": utc_now_iso(),
        }
        if authorization_granted:
            resolved_reconciliation.update(
                {
                    "reason": "write-authorization-resolved",
                    "authorization": "granted",
                }
            )
        self.store.transition_run(
            run_id,
            "recovering",
            event_type="workflow.reconciliation_resolved",
            payload={"action": action},
            reconciliation=resolved_reconciliation,
            lease=lease,
        )
        self.store.transition_run(
            run_id,
            "running",
            reconciliation=resolved_reconciliation,
            lease=lease,
        )
        return {"continue": True, "execution": execution}

    def _legacy_write_policy_failure(self, run_id: str, run: dict[str, Any]) -> bool:
        if str(run.get("error_code") or "") not in {
            "workflow_phase_failed",
            "phase_report_blocked",
        }:
            return False
        step = self.store.get_step(run_id, "architect.plan")
        if not step:
            return False
        output = self.store.load_artifact(step.get("output_artifact_id")) or {}
        text = json.dumps(output, ensure_ascii=False).lower()
        return any(
            marker in text
            for marker in (
                "regla de no modificar archivos",
                "bloqueada por la regla de no modificar",
                "read-only planning boundary",
                "rule not to modify files",
            )
        )

    def _restore_or_prepare_workspace(
        self,
        *,
        run_id: str,
        workspace_root: Path,
        config_snapshot: dict[str, Any],
        lease: LeaseToken,
    ) -> WorkspaceExecution:
        restored = self.workspace_manager.restore_or_reconstruct(
            run_id=run_id, workspace_root=workspace_root, lease=lease
        )
        if restored is not None:
            return restored
        workspace_cfg = config_snapshot["workspace"]
        return self.workspace_manager.prepare(
            run_id=run_id,
            workspace_root=workspace_root,
            mode=str(workspace_cfg.get("write_isolation") or "auto"),
            dirty_policy=str(workspace_cfg.get("dirty_workspace_policy") or "reject"),
            workspace_config=dict(workspace_cfg),
            lease=lease,
        )

    def _execute_participant(
        self,
        *,
        run_id: str,
        workspace_id: str,
        repository_identity: dict[str, Any],
        step_key: str,
        step_id: str,
        phase: str,
        profile: dict[str, Any],
        participant: dict[str, Any],
        ordinal: int,
        cwd: Path,
        prompt: str,
        report_kind: str,
        role: RoleConfig,
        lease: LeaseToken,
        config_snapshot: dict[str, Any],
    ) -> dict[str, Any]:
        """Run one already-materialized durable participant.

        Each worker uses the store's thread-local SQLite connection. Provider
        calls may overlap for read-only ``all`` phases while every state
        transition remains fenced by the workflow lease.
        """

        self.store.assert_lease(lease)
        if self.store.is_cancel_requested(run_id):
            raise WorkflowCancelled(
                f"Workflow {run_id} was cancelled during {step_key}."
            )
        sessions_cfg = config_snapshot.get("sessions") or {}
        identity_fingerprint = str(
            repository_identity.get("repository_fingerprint") or ""
        )
        lease_seconds = max(
            15, int(config_snapshot["durability"].get("lease_seconds") or 45)
        )
        heartbeat_seconds = int(
            config_snapshot["durability"].get("heartbeat_seconds") or 5
        )
        session_key = _session_key(
            workspace_id=workspace_id,
            run_id=run_id,
            step_key=step_key,
            role=phase,
            profile=profile,
        )
        provider_identity = provider_runtime_identity(str(profile["provider"]))
        provider_version = str(provider_identity.get("version") or "")
        if profile.get("agent_manifest_digest"):
            provider_version = f"{provider_version}|{profile['agent_manifest_digest']}"
        session = self.store.get_valid_session(
            session_key,
            identity_fingerprint=identity_fingerprint,
            provider_version=provider_version,
            ttl_hours=int(sessions_cfg.get("ttl_hours") or 24),
            max_turns=int(sessions_cfg.get("max_turns") or 20),
            invalidate_on_identity=bool(
                sessions_cfg.get("invalidate_on_repository_identity_change", True)
            ),
            invalidate_on_provider_version=bool(
                sessions_cfg.get("invalidate_on_provider_version_change", True)
            ),
        )
        attempt_number = int(participant.get("attempt_count") or 0) + 1
        attempt_key = _stable_hash(
            {
                "run": run_id,
                "step": step_key,
                "profile": profile["name"],
                "attempt": attempt_number,
            }
        )
        dispatch_fp = _stable_hash(
            {
                "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                "profile": profile,
                "cwd": str(cwd),
                "repository_fingerprint": identity_fingerprint,
            }
        )
        attempt, created = self.store.create_attempt(
            participant_id=str(participant["id"]),
            idempotency_key=attempt_key,
            session_key=session_key,
            owner=lease.owner,
            lease_seconds=lease_seconds,
            dispatch_fingerprint=dispatch_fp,
            lease=lease,
        )
        if not created and attempt["status"] == "succeeded":
            previous = self.store.load_artifact(attempt.get("result_artifact_id"))
            if isinstance(previous, dict):
                return {"ordinal": ordinal, "ok": True, "result": previous}
        attempt_id = str(attempt["id"])
        self.store.transition_attempt(attempt_id, "running", lease=lease)
        self.store.transition_participant(
            str(participant["id"]), "running", lease=lease
        )
        env = child_provider_env(
            run_id=run_id,
            workflow="architect-implement-review",
            role=phase,
            provider=str(profile["provider"]),
        )
        env.update(
            {
                "BALDR_DURABLE_STEP_ID": step_id,
                "BALDR_DURABLE_ATTEMPT_ID": attempt_id,
                "BALDR_EXECUTION_PROFILE": str(profile["name"]),
                "BALDR_LEASE_EPOCH": str(lease.epoch),
            }
        )
        if profile.get("agent_ref"):
            env["BALDR_AGENT_REF"] = str(profile["agent_ref"])
            env["BALDR_AGENT_MANIFEST_DIGEST"] = str(
                profile.get("agent_manifest_digest") or ""
            )
        heartbeat = LeaseHeartbeat(
            self.store,
            lease,
            lease_seconds,
            heartbeat_seconds,
            attempt_id=attempt_id,
        )

        def activity_sink(category: str) -> None:
            try:
                self.store.record_phase_activity(
                    run_id=run_id,
                    step_id=step_id,
                    attempt_id=attempt_id,
                    category=category,
                    lease=lease,
                )
            except Exception:
                return

        emit_provider_activity(activity_sink, generic_activity_for_role(phase))
        with heartbeat:
            try:
                provider_kwargs: dict[str, Any] = dict(
                    provider=str(profile["provider"]),
                    role_name=phase,
                    role=role,
                    cwd=cwd,
                    prompt=prompt,
                    workflow="architect-implement-review",
                    report_kind=report_kind,
                    extra_env=env,
                    profile_name=str(profile["name"]),
                    model=str(profile.get("model") or ""),
                    reasoning_effort=str(profile.get("reasoning_effort") or ""),
                    agent=str(profile.get("agent") or ""),
                    effort=str(profile.get("effort") or ""),
                    runner=str(profile.get("runner") or ""),
                    session_scope=str(profile.get("session_scope") or ""),
                    session_key=session_key,
                    resume_session_id=(session or {}).get("thread_id"),
                    durable_run_id=run_id,
                    durable_step_id=step_id,
                    durable_attempt_id=attempt_id,
                    agent_ref=str(profile.get("agent_ref") or ""),
                    agent_manifest_digest=str(
                        profile.get("agent_manifest_digest") or ""
                    ),
                )
                if _runner_accepts_activity_sink(self.provider_runner):
                    provider_kwargs["activity_sink"] = activity_sink
                result = self.provider_runner(**provider_kwargs)
            except (WorkflowCancelled, LeaseFenceError):
                raise
            except Exception as exc:
                reason = redact_text(f"Provider raised {type(exc).__name__}: {exc}")
                result = {
                    "ok": False,
                    "status": "failed",
                    "reason": reason,
                    "error": {
                        "code": "provider_unexpected_exception",
                        "message": reason,
                        "retryable": True,
                    },
                }
        if phase == "architect":
            result = _normalize_architect_write_authorization(
                result,
                authorization_required=not _has_persisted_direct_write_consent(
                    config_snapshot
                ),
            )
        heartbeat.raise_if_unhealthy()
        self.store.assert_lease(lease)
        artifact = self.store.store_artifact(
            run_id=run_id, kind=f"{phase}-provider-result", value=result
        )
        thread_id = result.get("thread_id")
        if thread_id or profile.get("session_scope"):
            self.store.upsert_session(
                session_key=session_key,
                provider=str(profile["provider"]),
                role=phase,
                profile_name=str(profile["name"]),
                model=str(profile.get("model") or ""),
                runner=str(profile.get("runner") or ""),
                thread_id=(
                    str(thread_id) if thread_id else (session or {}).get("thread_id")
                ),
                status="active" if result.get("ok") else "stale",
                metadata={
                    "last_provider_run_id": result.get("run_id"),
                    "last_step_id": step_id,
                },
                identity_fingerprint=identity_fingerprint,
                provider_version=provider_version,
                ttl_hours=int(sessions_cfg.get("ttl_hours") or 24),
                increment_turn=True,
                lease=lease,
                run_id=run_id,
            )
        if result.get("ok"):
            self.store.transition_attempt(
                attempt_id,
                "succeeded",
                provider_run_id=result.get("run_id"),
                result_artifact_id=artifact,
                lease=lease,
            )
            self.store.transition_participant(
                str(participant["id"]),
                "succeeded",
                result_artifact_id=artifact,
                lease=lease,
            )
            return {"ordinal": ordinal, "ok": True, "result": result}

        code = (
            (result.get("error") or {}).get("code")
            if isinstance(result.get("error"), dict)
            else None
        )
        reason = str(result.get("reason") or "provider execution failed")
        self.store.transition_attempt(
            attempt_id,
            "failed",
            provider_run_id=result.get("run_id"),
            result_artifact_id=artifact,
            error_code=code,
            error_reason=reason,
            lease=lease,
        )
        self.store.transition_participant(
            str(participant["id"]),
            "failed",
            result_artifact_id=artifact,
            error_code=code,
            error_reason=reason,
            lease=lease,
        )
        return {"ordinal": ordinal, "ok": False, "result": result}

    def _record_phase_failure(
        self,
        *,
        run_id: str,
        step_id: str,
        phase: str,
        output: dict[str, Any],
        error_code: str,
        reason: str,
        lease: LeaseToken,
    ) -> dict[str, Any]:
        """Persist a failed phase and its deliverable, returning its output.

        Every failure path stores the phase result, fails the durable step and
        materializes the deliverable in that order, so a client always finds the
        evidence for a failure it was told about.
        """
        artifact = self.store.store_artifact(
            run_id=run_id, kind=f"{phase}-phase-result", value=output
        )
        self.store.transition_step(
            step_id,
            "failed",
            output_artifact_id=artifact,
            error_code=error_code,
            error_reason=reason,
            lease=lease,
        )
        materialize_phase_deliverable(
            self.store,
            step_id=step_id,
            phase_output=output,
            lease=lease,
        )
        return output

    def _dispatch_participants_in_parallel(
        self,
        *,
        run_id: str,
        step_key: str,
        phase: str,
        prepared: list[tuple[int, dict[str, Any], dict[str, Any]]],
        invoke: Callable[[tuple[int, dict[str, Any], dict[str, Any]]], dict[str, Any]],
        max_concurrency: int,
    ) -> list[dict[str, Any]]:
        """Run read-only participants concurrently, cancellable mid-flight.

        Futures are waited on in short slices so a cancellation request is
        observed promptly, and any exit path terminates the spawned process tree
        before shutting the pool down.
        """
        outcomes: list[dict[str, Any]] = []
        executor = ThreadPoolExecutor(
            max_workers=min(max_concurrency, len(prepared)),
            thread_name_prefix=f"baldr-{phase}",
        )
        futures: set[Future[dict[str, Any]]] = {
            executor.submit(invoke, entry) for entry in prepared
        }
        try:
            while futures:
                if self.store.is_cancel_requested(run_id):
                    raise WorkflowCancelled(
                        f"Workflow {run_id} was cancelled during {step_key}."
                    )
                completed, futures = wait(
                    futures, timeout=0.2, return_when=FIRST_COMPLETED
                )
                for future in completed:
                    outcomes.append(future.result())
        except BaseException:
            terminate_processes_for_run(run_id, grace_seconds=0.75)
            for future in futures:
                future.cancel()
            executor.shutdown(wait=False, cancel_futures=True)
            raise
        executor.shutdown(wait=True)
        return outcomes

    def _dispatch_participants_serially(
        self,
        *,
        run_id: str,
        prepared: list[tuple[int, dict[str, Any], dict[str, Any]]],
        invoke: Callable[[tuple[int, dict[str, Any], dict[str, Any]]], dict[str, Any]],
        strategy: str,
        max_total_attempts: int,
    ) -> tuple[list[dict[str, Any]], bool]:
        """Run participants one at a time, stopping at the attempt budget.

        Returns the outcomes and whether the budget stopped the dispatch, which
        the caller reports differently from a participant failure.
        """
        outcomes: list[dict[str, Any]] = []
        for entry in prepared:
            if self.store.count_attempts_for_run(run_id) >= max_total_attempts:
                return outcomes, True
            outcome = invoke(entry)
            outcomes.append(outcome)
            if strategy == "first-success" and outcome.get("ok"):
                break
        return outcomes, False

    def _prepare_participants(
        self,
        *,
        run_id: str,
        step_key: str,
        step_id: str,
        profiles: list[dict[str, Any]],
        strategy: str,
        lease: LeaseToken,
    ) -> tuple[
        list[tuple[int, dict[str, Any], dict[str, Any]]],
        dict[int, dict[str, Any]],
    ]:
        """Split a phase's profiles into work to dispatch and results to replay.

        A participant that already succeeded contributes its recorded result, and
        under ``first-success`` it ends the search. The lease is re-checked per
        profile so a stale worker stops before creating durable rows.
        """
        prepared: list[tuple[int, dict[str, Any], dict[str, Any]]] = []
        successful_by_ordinal: dict[int, dict[str, Any]] = {}
        for ordinal, profile in enumerate(profiles):
            self.store.assert_lease(lease)
            if self.store.is_cancel_requested(run_id):
                raise WorkflowCancelled(
                    f"Workflow {run_id} was cancelled during {step_key}."
                )
            participant = self.store.create_participant(
                step_id=step_id, ordinal=ordinal, profile=profile, lease=lease
            )
            if participant["status"] == "succeeded":
                previous = self.store.load_artifact(
                    participant.get("result_artifact_id")
                )
                if isinstance(previous, dict):
                    successful_by_ordinal[ordinal] = previous
                    if strategy == "first-success":
                        break
                continue
            prepared.append((ordinal, profile, participant))
        return prepared, successful_by_ordinal

    def _settled_phase_result(
        self,
        *,
        run_id: str,
        step_key: str,
        lease: LeaseToken,
    ) -> dict[str, Any] | None:
        """Decide whether a durable step can be re-entered.

        A succeeded step replays its recorded output instead of running again. A
        write attempt with unknown effects is never retried blindly: it stays
        for reconciliation. Anything else interrupted is reset for a retry.
        """
        existing = self.store.get_step(run_id, step_key)
        if not existing:
            return None
        if existing["status"] == "succeeded":
            return self.store.load_artifact(existing.get("output_artifact_id")) or {
                "ok": False,
                "reason": "Durable step output artifact is missing.",
            }
        if existing["status"] == "unknown" and bool(existing.get("can_write")):
            return {
                "ok": False,
                "status": "unknown",
                "reason": "A previous write attempt has unknown effects and requires reconciliation.",
            }
        if existing["status"] in {"interrupted", "unknown", "failed"}:
            self.store.reset_step_for_retry(
                str(existing["id"]), reason="durable resume", lease=lease
            )
        return None

    def _execute_phase(
        self,
        *,
        run_id: str,
        workspace_id: str,
        repository_identity: dict[str, Any],
        step_key: str,
        phase: str,
        sequence_number: int,
        round_number: int,
        plan: dict[str, Any],
        cwd: Path,
        prompt: str,
        report_kind: str,
        lease: LeaseToken,
        config_snapshot: dict[str, Any],
        post_success: Callable[[str, list[dict[str, str]]], dict[str, Any]]
        | None = None,
    ) -> dict[str, Any]:
        if self.store.is_cancel_requested(run_id):
            raise WorkflowCancelled(
                f"Workflow {run_id} was cancelled before {step_key}."
            )
        settled = self._settled_phase_result(
            run_id=run_id, step_key=step_key, lease=lease
        )
        if settled is not None:
            return settled

        prompt_artifact = self.store.store_artifact(
            run_id=run_id,
            kind=f"{phase}-prompt-private",
            value=prompt,
            media_type="text/plain",
            redaction_level="private",
            redact=False,
        )
        step = self.store.create_step(
            run_id=run_id,
            step_key=step_key,
            phase=phase,
            sequence_number=sequence_number,
            round_number=round_number,
            strategy=str(plan["strategy"]),
            min_successes=int(plan["min_successes"]),
            can_write=bool(plan["can_write"]),
            sandbox=str(plan["sandbox"]),
            input_artifact_id=prompt_artifact,
            resolution=str(plan.get("resolution") or ""),
            min_approvals=int(plan.get("min_approvals") or 1),
            lease=lease,
        )
        step_id = str(step["id"])
        if step["status"] == "pending":
            self.store.transition_step(step_id, "dispatching", lease=lease)
            self.store.transition_step(step_id, "running", lease=lease)
        self._fault(
            f"step.{step_key}.running",
            {"run_id": run_id, "step_id": step_id, "lease_epoch": lease.epoch},
        )

        profiles = list(plan.get("profiles") or [])
        strategy = str(plan.get("strategy") or "first-success")
        max_concurrency = max(1, int(plan.get("max_concurrency") or 1))
        max_total_attempts = max(
            1,
            int(
                (config_snapshot.get("workflow") or {}).get(
                    "max_total_participant_attempts", 24
                )
            ),
        )

        def fail_before_dispatch(
            code: str,
            reason: str,
            *,
            participants: list[dict[str, Any]] | None = None,
        ) -> dict[str, Any]:
            output = {
                "ok": False,
                "status": "blocked",
                "error_code": code,
                "reason": reason,
                "participants": list(participants or []),
                "resolution": {
                    "policy": plan.get("resolution"),
                    "strategy": strategy,
                    "max_concurrency": max_concurrency,
                    "attempt_budget": max_total_attempts,
                },
            }
            return self._record_phase_failure(
                run_id=run_id,
                step_id=step_id,
                phase=phase,
                output=output,
                error_code=code,
                reason=reason,
                lease=lease,
            )

        if bool(plan.get("can_write")) and len(profiles) != 1:
            return fail_before_dispatch(
                "phase_writer_cardinality_invalid",
                (
                    f"Phase {phase!r} writes to the workspace and must resolve "
                    "to exactly one participant."
                ),
            )
        if bool(plan.get("can_write")):
            max_concurrency = 1

        role = _role_from_plan(plan)
        prepared, successful_by_ordinal = self._prepare_participants(
            run_id=run_id,
            step_key=step_key,
            step_id=step_id,
            profiles=profiles,
            strategy=strategy,
            lease=lease,
        )
        failed_by_ordinal: dict[int, dict[str, Any]] = {}

        used_attempts = self.store.count_attempts_for_run(run_id)
        if strategy == "all" and used_attempts + len(prepared) > max_total_attempts:
            return fail_before_dispatch(
                "workflow_attempt_budget_exhausted",
                (
                    f"Workflow attempt budget would be exceeded: {used_attempts} "
                    f"already used, {len(prepared)} requested, "
                    f"{max_total_attempts} allowed."
                ),
            )

        def invoke(entry: tuple[int, dict[str, Any], dict[str, Any]]) -> dict[str, Any]:
            ordinal, profile, participant = entry
            return self._execute_participant(
                run_id=run_id,
                workspace_id=workspace_id,
                repository_identity=repository_identity,
                step_key=step_key,
                step_id=step_id,
                phase=phase,
                profile=profile,
                participant=participant,
                ordinal=ordinal,
                cwd=cwd,
                prompt=prompt,
                report_kind=report_kind,
                role=role,
                lease=lease,
                config_snapshot=config_snapshot,
            )

        parallel = (
            strategy == "all"
            and not bool(plan.get("can_write"))
            and max_concurrency > 1
            and len(prepared) > 1
        )
        if parallel:
            outcomes = self._dispatch_participants_in_parallel(
                run_id=run_id,
                step_key=step_key,
                phase=phase,
                prepared=prepared,
                invoke=invoke,
                max_concurrency=max_concurrency,
            )
            budget_exhausted = False
        else:
            outcomes, budget_exhausted = self._dispatch_participants_serially(
                run_id=run_id,
                prepared=prepared,
                invoke=invoke,
                strategy=strategy,
                max_total_attempts=max_total_attempts,
            )

        for outcome in outcomes:
            ordinal = int(outcome["ordinal"])
            result = dict(outcome["result"])
            if outcome.get("ok"):
                successful_by_ordinal[ordinal] = result
            else:
                failed_by_ordinal[ordinal] = result
        successes = [
            successful_by_ordinal[ordinal] for ordinal in sorted(successful_by_ordinal)
        ]
        failures = [failed_by_ordinal[ordinal] for ordinal in sorted(failed_by_ordinal)]
        if budget_exhausted and not successes:
            return fail_before_dispatch(
                "workflow_attempt_budget_exhausted",
                (
                    f"Workflow attempt budget of {max_total_attempts} was exhausted "
                    f"during phase {phase!r}."
                ),
                participants=failures,
            )
        required = int(plan.get("min_successes") or 1)
        if len(successes) < required:
            output = {
                "ok": False,
                "status": "blocked",
                "error_code": "phase_min_successes_not_met",
                "reason": (
                    f"Phase {phase!r} produced {len(successes)} successful participant(s); "
                    f"{required} required."
                ),
                "participants": successes + failures,
                "resolution": {
                    "policy": plan.get("resolution"),
                    "min_successes": required,
                    "strategy": strategy,
                    "max_concurrency": max_concurrency,
                    "parallel": parallel,
                    "attempt_budget": max_total_attempts,
                    "attempts_consumed": self.store.count_attempts_for_run(run_id),
                },
            }
            return self._record_phase_failure(
                run_id=run_id,
                step_id=step_id,
                phase=phase,
                output=output,
                error_code="phase_min_successes_not_met",
                reason=str(output["reason"]),
                lease=lease,
            )

        output = reduce_phase(
            phase=phase,
            participants=successes,
            policy=str(plan.get("resolution") or ""),
            min_successes=required,
            min_approvals=int(plan.get("min_approvals") or 1),
        )
        raw_resolution = output.setdefault("resolution", {})
        if not isinstance(raw_resolution, dict):
            raw_resolution = {}
            output["resolution"] = raw_resolution
        raw_resolution.update(
            {
                "strategy": strategy,
                "max_concurrency": max_concurrency,
                "parallel": parallel,
                "attempt_budget": max_total_attempts,
                "attempts_consumed": self.store.count_attempts_for_run(run_id),
            }
        )
        if not output.get("ok"):
            return self._record_phase_failure(
                run_id=run_id,
                step_id=step_id,
                phase=phase,
                output=output,
                error_code=str(output.get("error_code") or "phase_report_blocked"),
                reason=str(output.get("reason") or "The phase reported blockers."),
                lease=lease,
            )
        if post_success:
            checkpoint = post_success(step_id, _reported_file_changes(output))
            output = {**output, "checkpoint": checkpoint}
        self.store.assert_lease(lease)
        artifact = self.store.store_artifact(
            run_id=run_id, kind=f"{phase}-phase-result", value=output
        )
        self.store.transition_step(
            step_id, "succeeded", output_artifact_id=artifact, lease=lease
        )
        materialize_phase_deliverable(
            self.store,
            step_id=step_id,
            phase_output=output,
            lease=lease,
        )
        self._fault(
            f"step.{step_key}.succeeded",
            {"run_id": run_id, "step_id": step_id, "lease_epoch": lease.epoch},
        )
        return output

    def _finish_failed(
        self,
        run_id: str,
        started: float,
        status: str,
        summary: str,
        detail: dict[str, Any],
        lease: LeaseToken,
        *,
        error_code: str = "workflow_phase_failed",
        execution: WorkspaceExecution | None = None,
    ) -> dict[str, Any]:
        report = {
            "status": status,
            "summary": summary,
            "detail": detail,
            "duration_ms": int((time.time() - started) * 1000),
        }
        artifact = self.store.store_artifact(
            run_id=run_id, kind="workflow-final-report", value=report
        )
        if execution is not None and execution.mode == "shadow":
            return self._retain_shadow_for_reconciliation(
                run_id=run_id,
                report=report,
                execution=execution,
                error_code=error_code,
                error_reason=summary,
                review_approved=False,
                lease=lease,
                final_artifact_id=artifact,
            )
        self.store.transition_run(
            run_id,
            status,
            final_artifact_id=artifact,
            error_code=error_code,
            error_reason=summary,
            lease=lease,
        )
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        self._append_telemetry(result)
        return result

    def _pause_for_write_authorization(
        self,
        *,
        run_id: str,
        request: str,
        execution: WorkspaceExecution,
        lease: LeaseToken,
        replay_architect: bool = False,
    ) -> dict[str, Any]:
        details = self.workspace_manager.reconciliation_status(execution)
        self.store.transition_run(
            run_id,
            "awaiting_reconciliation",
            event_type="workflow.write_authorization_requested",
            error_code="write_authorization_required",
            error_reason="Baldr necesita autorización para modificar archivos.",
            reconciliation={
                **details,
                "reason": "write-authorization-required",
                "message": "Baldr necesita autorización para modificar archivos.",
                "write_request": request,
                "allowed_actions": ["authorize_changes", "decline_changes"],
                "authorization": "pending",
                "replay_architect": replay_architect,
            },
            lease=lease,
        )
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        self._append_telemetry(result)
        return result

    def _retain_shadow_for_reconciliation(
        self,
        *,
        run_id: str,
        report: dict[str, Any],
        execution: WorkspaceExecution,
        error_code: str,
        error_reason: str,
        review_approved: bool,
        lease: LeaseToken,
        final_artifact_id: str | None = None,
    ) -> dict[str, Any]:
        artifact = final_artifact_id or self.store.store_artifact(
            run_id=run_id,
            kind="workflow-final-report",
            value=report,
        )
        details = self.workspace_manager.reconciliation_status(execution)
        self.store.transition_run(
            run_id,
            "awaiting_reconciliation",
            event_type="workflow.shadow_retained_for_reconciliation",
            final_artifact_id=artifact,
            error_code=error_code,
            error_reason=error_reason,
            reconciliation={
                "reason": "shadow-work-remains",
                "message": error_reason,
                "error_code": error_code,
                "review_approved": review_approved,
                **details,
            },
            lease=lease,
        )
        result = self._result_from_snapshot(self.store.snapshot_run(run_id))
        result["evidence"] = create_workflow_evidence(self.store, run_id)
        self._append_telemetry(result)
        return result

    def _result_from_snapshot(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        run = snapshot["run"]
        final = run.get("final") or {}
        steps = []
        for step in snapshot["steps"]:
            output = step.get("output") if isinstance(step.get("output"), dict) else {}
            profiles = [
                {
                    "name": p.get("profile_name"),
                    "provider": p.get("provider"),
                    "model": p.get("model"),
                    "reasoning_effort": p.get("reasoning_effort"),
                    "runner": p.get("runner"),
                    "agent_ref": p.get("agent_ref"),
                    "agent_manifest_digest": p.get("agent_manifest_digest"),
                    "agent_transport": p.get("agent_transport"),
                    "agent_registry": p.get("agent_registry"),
                    "status": p.get("status"),
                    "attempts": len(p.get("attempts") or []),
                }
                for p in step.get("participants", [])
            ]
            steps.append(
                {
                    "step": step.get("step_key"),
                    "phase": step.get("phase"),
                    "status": step.get("status"),
                    "strategy": step.get("strategy"),
                    "resolution": step.get("resolution"),
                    "coordination": output.get("resolution"),
                    "profiles": profiles,
                    "final_report": output.get("final_report"),
                    "reason": output.get("reason"),
                }
            )
        status = str(run["status"])
        return {
            "ok": status == "approved",
            "run_id": run["id"],
            "resume_token": run.get("resume_token"),
            "workflow": run["workflow_name"],
            "workflow_version": run["workflow_version"],
            "status": status,
            "workspace_root": run["workspace_root"],
            "workspace_id": run.get("workspace_id"),
            "request_fingerprint": run.get("request_fingerprint"),
            "started_at": run["created_at"],
            "updated_at": run["updated_at"],
            "recovery_count": run["recovery_count"],
            "lease_epoch": run.get("lease_epoch"),
            "cancel_requested_at": run.get("cancel_requested_at"),
            "reconciliation": run.get("reconciliation") or {},
            "coordination": (run.get("config_snapshot") or {}).get("coordination"),
            "error": (
                {
                    "code": run.get("error_code"),
                    "message": run.get("error_reason"),
                }
                if run.get("error_code")
                else None
            ),
            "steps": steps,
            "final_report": final,
            "durable": {
                "database_path": str(self.store.path),
                "schema_version": snapshot["schema"]["schema_version"],
                "event_count": len(snapshot["events"]),
                "checkpoint_count": len(snapshot["checkpoints"]),
                "session_count": len(snapshot["sessions"]),
            },
        }

    def _append_telemetry(self, result: dict[str, Any]) -> None:
        try:
            append_run(
                {
                    "run_id": result.get("run_id"),
                    "ok": result.get("ok"),
                    "provider": "workflow",
                    "runner": result.get("workflow"),
                    "workflow": result.get("workflow"),
                    "started_at": result.get("started_at") or utc_now_iso(),
                    "status": result.get("status"),
                    "durable_schema_version": result.get("durable", {}).get(
                        "schema_version"
                    ),
                    "lease_epoch": result.get("lease_epoch"),
                    "steps": [
                        {
                            "step": step.get("step"),
                            "status": step.get("status"),
                            "profiles": step.get("profiles"),
                        }
                        for step in result.get("steps", [])
                    ],
                }
            )
        except Exception:
            pass
